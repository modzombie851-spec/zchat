import { createRenderer } from './race3d.js';
import { townMeshes, townEnv } from './zmap.js';
import { buildBody, buildDog } from './zbody.js';
import { survLook, ZLOOKS, zLookIndex, DOGS, SURV_LOOK } from './zlooks.js';
import { gunMesh, magMesh } from './zguns.js';
import { buildFP, buildThrowFP, buildBatFP, makeFPState } from './zfp.js';
import { floorH } from './ztown.js';

export const OUTFIT_SWATCH = (sv, i) => { const b = SURV_LOOK[sv] || SURV_LOOK.jay; return b.outfits[i] || b.shirt; };
export const TIERS = [
  { name: 'Fast', dpr: 0.7, shadow: 0, grass: 0, trees: 0.25, zmax: 34, pmax: 12, post: false, near: 9, shadowN: 0 },
  { name: 'Balanced', dpr: 0.9, shadow: 1024, grass: 6500, trees: 0.5, zmax: 56, pmax: 20, post: false, near: 14, shadowN: 10 },
  { name: 'Best', dpr: 1.25, shadow: 2048, grass: 15000, trees: 1, zmax: 80, pmax: 40, post: true, near: 20, shadowN: 22 },
];

export function makeView(canvas, tierIdx) {
  const T = TIERS[tierIdx] || TIERS[1];
  const R = createRenderer(canvas, { shadowSize: T.shadow || 256, aa: tierIdx > 0 });
  if (!R) return null;
  const env = townEnv({ mood: 'dusk', shadowRange: 24 });
  env.shadows = !!T.shadow;
  env.detail = tierIdx > 0 ? 1 : 0;
  if (T.post) env.post = { bloom: 0.55, th: 0.8, sat: 0.84, con: 1.1, vig: 0.5, lo: [0.9, 0.97, 1.08], hi: [1.08, 0.98, 0.88] };
  const statics = [];
  const parts0 = townMeshes({ grassN: T.grass || 1, grass: T.grass > 0, grassAt: [8, -18, 74], treeKeep: T.trees, chunk: 24, dusk: true });
  for (const p of parts0) statics.push({ mesh: R.mesh(p.data), bs: p.bs, cast: p.cast && !!T.shadow, model: p.model });
  const cache = new Map();
  const human = (key, look, lod) => {
    let c = cache.get(key);
    if (c) return c;
    const B = buildBody(look, lod);
    c = { mesh: R.skin(B.data), joints: B.joints };
    cache.set(key, c);
    return c;
  };
  const surv = (sv, col, lod = 1) => human(`s:${sv}:${col}:${lod}`, survLook(sv, col), lod);
  const zomb = (k, id, lod = 1) => { const L = ZLOOKS[k] || ZLOOKS.walker; const i = zLookIndex(k, id); return human(`z:${k}:${i}:${lod}`, L[i], lod); };
  const dog = (key) => {
    const k = `d:${key}`;
    let c = cache.get(k);
    if (c) return c;
    const D = DOGS.find((d) => d.key === key) || DOGS[0];
    const B = buildDog(D, 1);
    c = { mesh: R.skin(B.data), joints: B.joints };
    cache.set(k, c);
    return c;
  };
  const gun = (kind) => { const k = `g:${kind}`; let c = cache.get(k); if (!c) { c = R.mesh(gunMesh(kind)); cache.set(k, c); } return c; };
  const fp = (kind, sv, col) => {
    const k = `fp:${kind}:${sv}:${col}`;
    let c = cache.get(k);
    if (!c) { c = Object.assign(makeFPState(), buildFP(R, kind, sv, col)); cache.set(k, c); }
    return c;
  };
  const V = { R, env, statics, surv, zomb, dog, gun, fp, tier: T, cache, dispose: () => { try { R.dispose(); } catch {} } };
  V.shell = R.mesh(magMesh('shotgun'));
  V.prepHands = (sv, col) => { V.nadeFP = buildThrowFP(R, 'grenade', sv, col); V.molFP = buildThrowFP(R, 'molotov', sv, col); V.batFP = buildBatFP(R, sv, col); };
  return V;
}

export function toWorld(x, z, yaw, p) { const c = Math.cos(yaw), s = Math.sin(yaw); return [x + p[0] * c + p[2] * s, p[1], z - p[0] * s + p[2] * c]; }
export const groundAt = floorH;
