const SHELL = 'zchat-shell-v3';
const STATIC = 'zchat-static-v1';
const REMOTE = 'zchat-remote-v1';
const SHARE = 'zchat-share';
const FONTS = 'zchat-fonts-v1';
const DECOR = 'zchat-decor-v1';
const STICKERS = 'zchat-stickers-v1';
const ASSET_LIMIT = 240;
const STATIC_LIMIT = 500;
const REMOTE_LIMIT = 700;
const STATIC_EXT = /\.(png|jpe?g|webp|gif|svg|ico|woff2?|ttf|otf)$/i;
const DECOR_PATH = /^\/set-[a-z0-9-]+\.webp$/i;
const STICKER_PATH = /^\/as-[a-z0-9]+-[a-z0-9]+\.webp$/;

function assetsIn(html) {
  const out = new Set();
  const re = /(?:src|href)=["'](\/assets\/[^"'?#]+)["']/g;
  let m;
  while ((m = re.exec(html))) out.add(m[1]);
  return [...out];
}

async function trim(cacheName, limit, keep) {
  try {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    const list = keep ? keys.filter((r) => new URL(r.url).pathname.startsWith('/assets/')) : keys;
    let extra = list.length - limit;
    for (let i = 0; i < list.length && extra > 0; i++) {
      const path = new URL(list[i].url).pathname;
      if (keep && keep.has(path)) continue;
      await cache.delete(list[i]);
      extra -= 1;
    }
  } catch {}
}

async function storeShell(cache, res) {
  const html = await res.clone().text();
  const assets = assetsIn(html);
  for (const a of assets) {
    if (await cache.match(a)) continue;
    const r = await fetch(a);
    if (!r || !r.ok) return false;
    await cache.put(a, r);
  }
  await cache.put('/', res);
  return { html, assets };
}

async function shellComplete(cache, hit) {
  try {
    const html = await hit.clone().text();
    const assets = assetsIn(html);
    if (!assets.length) return false;
    const found = await Promise.all(assets.map((a) => cache.match(a)));
    return found.every(Boolean) ? html : false;
  } catch {
    return false;
  }
}

async function refreshShell(oldHtml) {
  try {
    const cache = await caches.open(SHELL);
    const res = await fetch('/', { cache: 'no-cache' });
    if (!res || !res.ok || res.type !== 'basic' || !(res.headers.get('content-type') || '').includes('text/html')) return;
    const html = await res.clone().text();
    if (oldHtml && html === oldHtml) return;
    const stored = await storeShell(cache, res);
    if (!stored) return;
    const keep = new Set([...stored.assets, ...(oldHtml ? assetsIn(oldHtml) : [])]);
    await trim(SHELL, ASSET_LIMIT, keep);
    if (oldHtml) {
      const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      list.forEach((c) => { try { c.postMessage({ type: 'zchat-update-ready' }); } catch {} });
    }
  } catch {}
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    try {
      const cache = await caches.open(SHELL);
      const res = await fetch('/', { cache: 'no-cache' });
      if (res && res.ok && (res.headers.get('content-type') || '').includes('text/html')) await storeShell(cache, res);
      await cache.addAll(['/manifest.json', '/icon-192.png', '/icon-512.png', '/badge-192.png']).catch(() => {});
    } catch {}
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => (k.startsWith('zchat-shell-') && k !== SHELL) || (k.startsWith('zchat-stickers-') && k !== STICKERS)).map((k) => caches.delete(k)));
    await tidyStatic();
    await self.clients.claim();
  })());
});

async function navigation(event) {
  const cache = await caches.open(SHELL);
  const hit = await cache.match('/');
  if (hit) {
    const html = await shellComplete(cache, hit);
    if (html) {
      event.waitUntil(refreshShell(html));
      return hit;
    }
  }
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 9000);
    const res = await fetch(event.request, { signal: ctrl.signal });
    clearTimeout(timer);
    if (res && res.ok && res.type === 'basic' && (res.headers.get('content-type') || '').includes('text/html')) {
      event.waitUntil(storeShell(cache, res.clone()).then(() => trim(SHELL, ASSET_LIMIT, null)).catch(() => {}));
    }
    return res;
  } catch (err) {
    if (hit) return hit;
    const any = await cache.match(event.request, { ignoreSearch: true });
    if (any) return any;
    throw err;
  }
}

async function assetFirst(request) {
  const cache = await caches.open(SHELL);
  const hit = await cache.match(request, { ignoreSearch: true });
  if (hit && realFile(hit)) return hit;
  if (hit) cache.delete(request).catch(() => {});
  const res = await fetch(request);
  if (realFile(res)) cache.put(request, res.clone()).catch(() => {});
  return res;
}

async function stamped(res) {
  const headers = new Headers(res.headers);
  headers.set('x-zc-at', String(Date.now()));
  const body = await res.blob();
  return new Response(body, { status: res.status, statusText: res.statusText, headers });
}

function realFile(res) {
  if (!res || !res.ok || res.type !== 'basic' || res.status !== 200) return false;
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  return !ct.includes('text/html');
}

function keptFile(res) {
  if (!res || res.status !== 200) return false;
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  return !ct.includes('text/html');
}

async function tidyStatic() {
  try {
    const cache = await caches.open(STATIC);
    const decor = await caches.open(DECOR);
    const reqs = await cache.keys();
    for (const req of reqs) {
      const res = await cache.match(req);
      let path = '';
      try { path = new URL(req.url).pathname; } catch {}
      if (!keptFile(res) || (DECOR_PATH.test(path) && await decor.match(path))) await cache.delete(req);
    }
  } catch {}
}

async function decorFile(event) {
  const request = event.request;
  const key = new URL(request.url).pathname;
  let store = null;
  try {
    store = await caches.open(DECOR);
    const hit = await store.match(key);
    if (hit) return hit;
    const stat = await caches.open(STATIC);
    const old = await stat.match(request, { ignoreSearch: true });
    if (keptFile(old)) {
      event.waitUntil(store.put(key, old.clone()).then(() => stat.delete(request, { ignoreSearch: true })).catch(() => {}));
      return old;
    }
  } catch {}
  const res = await fetch(request);
  if (store && realFile(res) && !request.headers.has('x-zc-save')) event.waitUntil(store.put(key, res.clone()).catch(() => {}));
  return res;
}

async function stickerFile(event) {
  const request = event.request;
  const key = new URL(request.url).pathname;
  let store = null;
  try {
    store = await caches.open(STICKERS);
    const hit = await store.match(key);
    if (hit) return hit;
  } catch {}
  const res = await fetch(request);
  if (store && realFile(res)) event.waitUntil(store.put(key, res.clone()).catch(() => {}));
  return res;
}

async function staticFile(event) {
  const request = event.request;
  const cache = await caches.open(STATIC);
  const hit = await cache.match(request, { ignoreSearch: true });
  const update = () => fetch(request).then(async (res) => {
    if (realFile(res)) {
      const copy = await stamped(res.clone());
      await cache.put(request, copy);
      trim(STATIC, STATIC_LIMIT, null);
    }
    return res;
  });
  if (hit) {
    const at = Number(hit.headers.get('x-zc-at') || 0);
    if (Date.now() - at > 21600000) event.waitUntil(update().catch(() => {}));
    return hit;
  }
  return update();
}

async function remoteImage(event) {
  const request = event.request;
  const cache = await caches.open(REMOTE);
  const hit = await cache.match(request.url);
  if (hit) return hit;
  try {
    const res = await fetch(request.url, { mode: 'cors', credentials: 'omit' });
    if (res && res.ok && res.status === 200) {
      event.waitUntil(cache.put(request.url, res.clone()).then(() => trim(REMOTE, REMOTE_LIMIT, null)).catch(() => {}));
      return res;
    }
  } catch {}
  return fetch(request);
}

async function fontFile(event) {
  const request = event.request;
  const cache = await caches.open(FONTS);
  const hit = await cache.match(request.url);
  const css = new URL(request.url).hostname === 'fonts.googleapis.com';
  const update = () => fetch(request).then(async (res) => {
    if (res && (res.ok || res.type === 'opaque')) {
      await cache.put(request.url, res.clone());
      trim(FONTS, 80, null);
    }
    return res;
  });
  if (hit) {
    if (css) event.waitUntil(update().catch(() => {}));
    return hit;
  }
  return update();
}

async function receiveShare(event) {
  try {
    const form = await event.request.formData();
    const files = form.getAll('media').filter((f) => f && typeof f === 'object' && f.size > 0);
    const text = ['title', 'text', 'url'].map((k) => form.get(k)).filter((v) => typeof v === 'string' && v.trim()).join('\n').trim();
    const cache = await caches.open(SHARE);
    await Promise.all((await cache.keys()).map((k) => cache.delete(k)));
    let count = 0;
    for (const f of files.slice(0, 10)) {
      await cache.put(`/__share/file-${count}`, new Response(f, { headers: { 'content-type': f.type || 'application/octet-stream', 'x-name': encodeURIComponent(f.name || `file-${count}`) } }));
      count += 1;
    }
    await cache.put('/__share/meta', new Response(JSON.stringify({ text, count, at: Date.now() }), { headers: { 'content-type': 'application/json' } }));
  } catch {}
  return Response.redirect('/?share=1', 303);
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  let url;
  try { url = new URL(request.url); } catch { return; }
  if (url.origin !== self.location.origin) {
    if (request.method !== 'GET') return;
    if (request.destination === 'image' && /\.supabase\.co$/.test(url.hostname) && url.pathname.indexOf('/storage/v1/object/public/') === 0) {
      event.respondWith(remoteImage(event));
      return;
    }
    if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
      event.respondWith(fontFile(event));
    }
    return;
  }
  if (request.method === 'POST' && url.pathname === '/share-target') {
    event.respondWith(receiveShare(event));
    return;
  }
  if (request.method !== 'GET' || url.pathname.startsWith('/.netlify/') || url.pathname.startsWith('/__')) return;
  if (request.mode === 'navigate') {
    if (!/\.[a-z0-9]{2,5}$/i.test(url.pathname)) event.respondWith(navigation(event));
    return;
  }
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(assetFirst(request));
    return;
  }
  if (STICKER_PATH.test(url.pathname) && !request.headers.has('range')) {
    event.respondWith(stickerFile(event));
    return;
  }
  if (DECOR_PATH.test(url.pathname) && !request.headers.has('range')) {
    event.respondWith(decorFile(event));
    return;
  }
  if (STATIC_EXT.test(url.pathname) && !request.headers.has('range')) {
    event.respondWith(staticFile(event));
  }
});

const SW_CAPS = 1;
const TAG_KEYS = ['dm', 'group', 'channel', 'post', 'story', 'live', 'call', 'profile'];
const CLOSE_LATER_MS = 4000;

function tagFor(url) {
  try {
    const u = new URL(url || '/', self.location.origin);
    for (const key of TAG_KEYS) {
      const id = u.searchParams.get(key);
      if (id && /^[A-Za-z0-9-]{1,80}$/.test(id)) return `${key}-${id}`;
    }
    if (u.searchParams.get('requests')) return 'requests';
    if (u.searchParams.get('mail')) return 'mail';
  } catch {}
  return '';
}

function isChatTag(tag) {
  return /^(dm|group|channel)-/.test(tag || '');
}

async function readPref(key) {
  try {
    const cache = await caches.open('zchat-prefs');
    const hit = await cache.match(key);
    return hit ? await hit.json() : null;
  } catch {
    return null;
  }
}

const VIBES = { short: [60], long: [480], double: [90, 110, 90], heartbeat: [70, 110, 150, 600, 70, 110, 150], off: [0] };

function quietHoursNow(q) {
  if (!q || !q.on) return false;
  const from = Number.isInteger(q.from) ? q.from : 22;
  const to = Number.isInteger(q.to) ? q.to : 7;
  const h = new Date().getHours();
  return from === to ? true : from < to ? h >= from && h < to : h >= from || h < to;
}

function accountOf(url) {
  try { return new URL(url || '/', self.location.origin).searchParams.get('acc') || ''; } catch { return ''; }
}

function noteAccount(n) {
  const d = (n && n.data) || {};
  return typeof d.acc === 'string' ? d.acc : accountOf(d.url);
}

function sameAccount(n, acc) {
  const a = noteAccount(n);
  return !acc || !a || a === acc;
}

function shownAt(n) {
  const d = (n && n.data) || {};
  return Number(d.at) || Number(n && n.timestamp) || 0;
}

async function windowVisible() {
  try {
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    return list.some((c) => c.visibilityState === 'visible');
  } catch {
    return false;
  }
}

async function closeTag(tag, acc, before) {
  try {
    const list = await self.registration.getNotifications({ tag });
    list.forEach((n) => { if (sameAccount(n, acc) && (!before || shownAt(n) <= before)) n.close(); });
  } catch {}
  await syncBadge();
}

async function clearPushed(data) {
  const tag = typeof data.tag === 'string' ? data.tag : '';
  const acc = typeof data.acc === 'string' ? data.acc : '';
  if (!tag) return;
  let mine = [];
  let others = 0;
  try {
    const all = await self.registration.getNotifications();
    all.forEach((n) => { if (n.tag === tag && sameAccount(n, acc)) mine.push(n); else others += 1; });
  } catch {
    return;
  }
  if (!mine.length) return;
  if (others > 0 || await windowVisible()) {
    mine.forEach((n) => n.close());
    await syncBadge();
    return;
  }
  const before = Date.now();
  setTimeout(() => { closeTag(tag, acc, before); }, CLOSE_LATER_MS);
}

self.addEventListener('push', (event) => {
  let data = { title: 'ZChat', body: 'You have a new message', url: '/', icon: '/icon-192.png' };
  try { data = { ...data, ...event.data.json() }; } catch {}
  if (data.type === 'clear') {
    event.waitUntil(clearPushed(data));
    return;
  }
  const hush = typeof data.body === 'string' && data.body.charCodeAt(0) === 0x2063;
  if (hush) data.body = data.body.slice(1);
  event.waitUntil((async () => {
    const tag = (typeof data.tag === 'string' && data.tag) || tagFor(data.url);
    const acc = accountOf(data.url);
    if (tag) {
      const hidden = await readPref('/__hidden');
      const keys = Array.isArray(hidden) ? hidden : (hidden && acc && Array.isArray(hidden[acc]) ? hidden[acc] : []);
      if (keys.includes(tag)) {
        await self.registration.showNotification('ZChat', {
          body: 'You have a new message',
          icon: '/icon-192.png',
          badge: '/badge-192.png',
          tag: 'zchat-private',
          renotify: true,
          data: { url: acc ? `/?acc=${encodeURIComponent(acc)}` : '/', acc, at: Date.now() },
        });
        return;
      }
      const limited = await readPref('/__restricted');
      const rkeys = limited && acc && Array.isArray(limited[acc]) ? limited[acc] : [];
      if (rkeys.includes(tag)) {
        await self.registration.showNotification('ZChat', {
          body: 'New message request',
          icon: '/icon-192.png',
          badge: '/badge-192.png',
          tag: 'zchat-requests',
          silent: true,
          renotify: false,
          data: { url: acc ? `/?acc=${encodeURIComponent(acc)}` : '/', acc, at: Date.now() },
        });
        return;
      }
    }
    const [focus, quietPref, vipPref, vibePref] = await Promise.all([readPref('/__focus'), readPref('/__quiet'), readPref('/__vip'), readPref('/__vibe')]);
    const from = typeof data.from === 'string' ? data.from : '';
    const vips = vipPref && acc && Array.isArray(vipPref[acc]) ? vipPref[acc] : [];
    const sleepy = quietHoursNow(quietPref) && !(from && vips.includes(from));
    const quiet = hush || sleepy || !!(focus && Number(focus.until) > Date.now() && tag !== focus.chat);
    const vibes = vibePref && acc && vibePref[acc] && typeof vibePref[acc] === 'object' ? vibePref[acc] : {};
    const vibe = tag && typeof vibes[tag] === 'string' ? VIBES[vibes[tag]] : null;
    let title = data.title;
    let count = 1;
    if (tag && isChatTag(tag)) {
      try {
        const open = await self.registration.getNotifications({ tag });
        const prev = open[open.length - 1];
        if (prev && noteAccount(prev) === acc) count = (Number(prev.data && prev.data.count) || 1) + 1;
      } catch {}
      if (count > 1) title = `${data.title} (${count} new messages)`;
    }
    const options = {
      body: data.body,
      icon: data.icon || '/icon-192.png',
      badge: '/badge-192.png',
      data: { url: data.url, count, baseTitle: data.title, acc, at: Date.now() },
    };
    if (quiet) options.silent = true;
    else if (vibe) options.vibrate = vibe;
    if (tag) { options.tag = tag; options.renotify = !quiet && data.renotify !== false; }
    await self.registration.showNotification(title, options);
    await syncBadge();
  })());
});

async function syncBadge() {
  try {
    const nav = self.navigator;
    if (!nav || !('setAppBadge' in nav)) return;
    const list = await self.registration.getNotifications();
    let n = 0;
    list.forEach((x) => { n += (x.data && x.data.count) || 1; });
    if (n > 0) await nav.setAppBadge(n); else await nav.clearAppBadge();
  } catch {}
}

self.addEventListener('notificationclose', (event) => { event.waitUntil(syncBadge()); });

self.addEventListener('message', (event) => {
  const d = event.data || {};
  if (d.type === 'zchat-clear-notifications') {
    event.waitUntil((async () => {
      try {
        const list = await self.registration.getNotifications(d.tag ? { tag: d.tag } : undefined);
        list.forEach((x) => { if (sameAccount(x, typeof d.acc === 'string' ? d.acc : '')) x.close(); });
      } catch {}
      await syncBadge();
    })());
    return;
  }
  if (d.type === 'zchat-sw-caps') {
    try { if (event.ports && event.ports[0]) event.ports[0].postMessage({ caps: SW_CAPS }); } catch {}
  }
});

function askClient(client, url) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    const timer = setTimeout(() => finish(false), 1500);
    try {
      const channel = new MessageChannel();
      channel.port1.onmessage = (e) => { clearTimeout(timer); finish(!!(e.data && e.data.ok)); };
      client.postMessage({ type: 'zchat-open', url }, [channel.port2]);
    } catch {
      clearTimeout(timer);
      finish(false);
    }
  });
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  let url = (event.notification.data && event.notification.data.url) || '/';
  try { const u = new URL(url, self.location.origin); url = u.origin === self.location.origin ? u.href : '/'; } catch { url = '/'; }
  event.waitUntil((async () => {
    await syncBadge();
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const client = list.find((c) => c.url.startsWith(self.location.origin));
    if (client) {
      try { await client.focus(); } catch {}
      const handled = await askClient(client, url);
      if (!handled) {
        try { await client.navigate(url); } catch {}
      }
      return;
    }
    if (self.clients.openWindow) await self.clients.openWindow(url);
  })());
});
